// ============================================================================
// Qwen-Rapid-AIO Series Batch - Cloudflare Worker v1.0 (Serverless)
// ----------------------------------------------------------------------------
// 動作:
//   RunPod Serverless Endpoint に対して 1入力画像 × 5 Positive で 5枚直列生成。
//   各画像はブラウザ側で Google Drive にアップロード（OAuth token使用）。
//
// 主要機能:
//   - Settings: RunPod API Key + Endpoint ID（Cloudflare KV 全端末同期）
//   - Google Drive: OAuth Client ID / Picker API Key / 出力フォルダ（KV同期）
//   - 5 Positive Prompts + 共通 Negative + Seed + 3 LoRA (breast/snofs/vagina)
//   - Drive Picker で入力画像1枚選択
//   - プリセット保存（5 Pos + Neg + Seed + LoRA + シリーズ名 まるごと、KV）
//   - 5枚直列実行 + Polling 進捗表示 + Drive アップロード
//
// 設計判断（Pod駆動版との違い）:
//   - Pod ID → Endpoint ID
//   - Pod自動Resume/Stop → 不要（Serverless自動スケール）
//   - Pod内常駐 → ブラウザ側で実行管理（タブを閉じると停止）
//   - rclone保存 → ブラウザがDrive APIで直接アップロード
//
// 前提:
//   - worker.js 冒頭の BASE_WORKFLOW に Qwen-Rapid-AIO の workflow_api.json を貼付
//   - Cloudflare KV namespace "QWEN" バインディング済み
//   - RunPod Serverless Endpoint 稼働中（GitHub: kurox1997/QWEN）
//
// デプロイ:
//   Cloudflare Dashboard → Workers → qwen → Edit Code → 全削除 → 貼付 → Deploy
// ============================================================================

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS, PUT, DELETE",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

const DEFAULT_NEGATIVE = "bad anatomy, deformed anatomy, extra limbs, extra fingers, mutated hands, fused fingers, bad hands, low quality, worst quality, blurry, deformed, ugly, jpeg artifacts, watermark, text, logo, censored, mosaic";

// ★★★ Qwen-Rapid-AIO_SImple (API).json を組み込み済み ★★★
const BASE_WORKFLOW = {
  "1": {
    "inputs": {
      "ckpt_name": "Qwen-Rapid-AIO-NSFW-v23.safetensors"
    },
    "class_type": "CheckpointLoaderSimple",
    "_meta": {
      "title": "チェックポイントを読み込む"
    }
  },
  "431": {
    "inputs": {
      "prompt": "different face, changed face, wrong face, altered face, deformed face, bad anatomy, low quality, blurry, artifacts, extra limbs, faces apart, no contact, mouths closed, tongue hidden, tongues not touching, separate faces, distant from each other, licking wrong body part",
      "clip": [
        "1",
        1
      ],
      "vae": [
        "1",
        2
      ],
      "image1": [
        "449",
        0
      ]
    },
    "class_type": "TextEncodeQwenImageEditPlus",
    "_meta": {
      "title": "TextEncodeQwenImageEditPlus Negative"
    }
  },
  "432": {
    "inputs": {
      "image": [
        "449",
        0
      ]
    },
    "class_type": "GetImageSize",
    "_meta": {
      "title": "画像サイズ取得"
    }
  },
  "433": {
    "inputs": {
      "width": [
        "432",
        0
      ],
      "height": [
        "432",
        1
      ],
      "batch_size": 1
    },
    "class_type": "EmptyLatentImage",
    "_meta": {
      "title": "Final Image Size"
    }
  },
  "434": {
    "inputs": {
      "seed": 19,
      "steps": 6,
      "cfg": 1,
      "sampler_name": "euler_ancestral",
      "scheduler": "simple",
      "denoise": 1,
      "model": [
        "900",
        0
      ],
      "positive": [
        "440",
        0
      ],
      "negative": [
        "431",
        0
      ],
      "latent_image": [
        "433",
        0
      ]
    },
    "class_type": "KSampler",
    "_meta": {
      "title": "Kサンプラー (SageAttention 2.x patched)"
    }
  },
  "435": {
    "inputs": {
      "samples": [
        "434",
        0
      ],
      "vae": [
        "1",
        2
      ]
    },
    "class_type": "VAEDecode",
    "_meta": {
      "title": "VAEデコード"
    }
  },
  "436": {
    "inputs": {
      "lora_name": "SNOFSv1.3.safetensors",
      "strength_model": 0.5,
      "model": [
        "438",
        0
      ]
    },
    "class_type": "LoraLoaderModelOnly",
    "_meta": {
      "title": "LoRA: SNOFS"
    }
  },
  "438": {
    "inputs": {
      "lora_name": "QWEN_breastslider.safetensors",
      "strength_model": -2,
      "model": [
        "1",
        0
      ]
    },
    "class_type": "LoraLoaderModelOnly",
    "_meta": {
      "title": "LoRA: breastslider"
    }
  },
  "440": {
    "inputs": {
      "prompt": "服をドレスに変える",
      "clip": [
        "1",
        1
      ],
      "vae": [
        "1",
        2
      ],
      "image1": [
        "449",
        0
      ]
    },
    "class_type": "TextEncodeQwenImageEditPlus",
    "_meta": {
      "title": "TextEncodeQwenImageEditPlus Positive"
    }
  },
  "443": {
    "inputs": {
      "filename_prefix": "Nude01",
      "images": [
        "435",
        0
      ]
    },
    "class_type": "SaveImage",
    "_meta": {
      "title": "画像を保存"
    }
  },
  "449": {
    "inputs": {
      "image": "ComfyUI_00006_.png"
    },
    "class_type": "LoadImage",
    "_meta": {
      "title": "画像を読み込む"
    }
  },
  "451": {
    "inputs": {
      "lora_name": "QWEN_WhatIsVagina.safetensors",
      "strength_model": 0.5,
      "model": [
        "436",
        0
      ]
    },
    "class_type": "LoraLoaderModelOnly",
    "_meta": {
      "title": "LoRA: WhatIsVagina"
    }
  },
  "900": {
    "inputs": {
      "sage_attention": "sageattn_qk_int8_pv_fp16_cuda",
      "model": [
        "451",
        0
      ]
    },
    "class_type": "PathchSageAttentionKJ",
    "_meta": {
      "title": "Patch Sage Attention (CUDA backend, Qwen safe)"
    }
  }
};

// 編集対象ノードID（workflow.json側のノードIDに合わせて調整）
const NODE = {
  POS_PROMPT:   '440',
  NEG_PROMPT:   '431',
  SEED:         '434',
  LORA_BREAST:  '438',
  LORA_SNOFS:   '436',
  LORA_VAGINA:  '451',
  INPUT_IMAGE:  '449',
  PATCH_SAGE:   '900'  // KJNodes Patch Sage Attention (RTX 4090, Qwen safe)
};

const HTML = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title>Qwen-Rapid-AIO Series v1.0</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
:root{--bg:#0a0a0c;--surface:#141418;--surface2:#1c1c22;--border:#2a2a33;--text:#e8e8ed;--dim:#6b6b7b;--accent:#6366f1;--accent2:#818cf8;--green:#22c55e;--amber:#f59e0b;--red:#ef4444;--blue:#3b82f6}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;-webkit-tap-highlight-color:transparent;font-size:16px}
.app{max-width:920px;margin:0 auto;padding:14px 14px 80px}
.header{text-align:center;padding:14px 0 10px}
.header h1{font-family:'Space Mono',monospace;font-size:22px;font-weight:700}
.header h1 span{color:var(--accent2)}
.header p{color:var(--dim);font-size:11px;margin-top:4px;font-family:'Space Mono',monospace}
.card{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:14px;margin-bottom:12px}
.card h2{font-size:13px;color:var(--accent2);margin-bottom:10px;font-family:'Space Mono',monospace;letter-spacing:1px;text-transform:uppercase}
.card h2 small{color:var(--dim);font-weight:400;text-transform:none;letter-spacing:0;margin-left:8px}
label{display:block;font-size:12px;color:var(--dim);margin:8px 0 4px;font-weight:500}
input,textarea,select{width:100%;padding:11px 12px;background:var(--surface2);border:1px solid var(--border);border-radius:7px;color:var(--text);font-size:16px;font-family:inherit;transition:border .15s}
input:focus,textarea:focus,select:focus{outline:0;border-color:var(--accent)}
textarea{resize:vertical;min-height:80px;line-height:1.5}
.row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
button{cursor:pointer;border:0;font-family:inherit;font-weight:600;transition:all .15s;-webkit-appearance:none}
.btn{padding:10px 14px;background:var(--surface2);border:1px solid var(--border);color:var(--text);border-radius:7px;font-size:14px}
.btn:hover{border-color:var(--accent)}
.btn-large{width:100%;padding:14px;font-size:15px;border-radius:8px;letter-spacing:.3px}
.btn-success{background:var(--green);color:#fff}
.btn-success:disabled{opacity:.5;cursor:not-allowed}
.btn-danger{background:var(--red);color:#fff}
.btn-warn{background:var(--amber);color:#000}
.btn-secondary{background:var(--accent);color:#fff}
.toggle-row{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:13px}
.toggle-row input[type=checkbox]{width:auto;margin:0}
.badge{display:inline-block;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:600;font-family:'Space Mono',monospace}
.badge.idle{background:var(--surface2);color:var(--dim)}
.badge.running{background:rgba(245,158,11,.2);color:var(--amber)}
.badge.done{background:rgba(34,197,94,.2);color:var(--green)}
.badge.error{background:rgba(239,68,68,.2);color:var(--red)}
.progress-bar{width:100%;height:8px;background:var(--surface2);border-radius:99px;overflow:hidden;margin-top:8px}
.progress-bar .fill{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .5s;border-radius:99px}
.log{background:#000;color:#0f0;padding:8px;border-radius:6px;font-family:'Space Mono',monospace;font-size:10px;max-height:240px;overflow-y:auto;white-space:pre-wrap;line-height:1.4;margin-top:8px}
.footer{text-align:center;padding:18px;color:var(--dim);font-size:10px;font-family:'Space Mono',monospace}
.connected{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--red);margin-right:6px;vertical-align:middle}
.connected.ok{background:var(--green)}
details{margin-top:8px}
summary{cursor:pointer;font-size:12px;color:var(--dim);padding:4px 0}
summary:hover{color:var(--text)}
.banner{padding:10px 12px;border-radius:7px;font-size:12px;margin-bottom:10px;background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.3);color:#93c5fd}
.banner.warn{background:rgba(245,158,11,.1);border-color:rgba(245,158,11,.3);color:#fbbf24}
.banner.error{background:rgba(239,68,68,.1);border-color:rgba(239,68,68,.3);color:#fca5a5}
.banner.success{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.3);color:#86efac}
.completed-item{padding:6px 0;border-bottom:1px solid var(--border);font-size:11px;display:flex;justify-content:space-between;font-family:'Space Mono',monospace}
.completed-item:last-child{border-bottom:0}
.completed-item .ok{color:var(--green)}
.completed-item .ng{color:var(--red)}
.folder-display{font-family:'Space Mono',monospace;font-size:11px;color:var(--dim);padding:6px 8px;background:var(--surface2);border-radius:5px;margin-top:4px;word-break:break-all}
.folder-display.set{color:var(--green)}
.gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-top:12px}
.gallery img{width:100%;border-radius:6px;border:1px solid var(--border);display:block}
.gallery .cap{font-size:10px;color:var(--dim);text-align:center;margin-top:4px;font-family:'Space Mono',monospace}
@media(max-width:600px){.row{grid-template-columns:1fr}.app{padding:8px 10px 80px}.header{padding:8px 0 6px}.header h1{font-size:18px}}
</style>
</head>
<body>
<div class="app">
<div class="header"><h1>Qwen-Rapid-AIO <span>Series</span></h1><p>5 Positive × 1 Image · 3 LoRA · Serverless</p></div>

<div class="card">
<h2>Settings <small><span id="connDot" class="connected"></span><span id="connText">未接続</span></small></h2>
<label>RunPod API Key</label>
<input type="password" id="apiKey" placeholder="rpa_xxx" autocomplete="off">
<label>Endpoint ID <small style="color:var(--dim)">(Serverless Endpoint、KV同期)</small></label>
<input type="text" id="endpointId" placeholder="例: vo0thha479d0xg">
<div class="row">
<button class="btn btn-secondary" id="saveBtn">💾 ローカル＋KV 一括保存</button>
<button class="btn" id="testBtn">🔌 接続確認</button>
</div>
</div>

<div class="card">
<h2>Google Drive <small id="configStatus" style="color:var(--dim);font-size:11px"></small></h2>
<div id="driveStatus" style="font-size:12px;color:var(--dim);margin-bottom:8px">未接続</div>
<button class="btn btn-secondary btn-large" id="driveAuthBtn">📁 Drive 接続 (OAuth)</button>

<div style="background:var(--surface2);padding:10px;border-radius:7px;margin-top:12px;border:1px solid var(--border)">
<div style="font-size:11px;color:var(--accent2);margin-bottom:8px;font-family:'Space Mono',monospace">☁️ Cloudflare KV同期項目（全端末共有）</div>

<label>OAuth Client ID</label>
<input type="text" id="googleClientId" placeholder="xxxxx.apps.googleusercontent.com">

<label>Picker API Key <small style="color:var(--dim)">(Google Cloud > APIs > Credentials > API Key)</small></label>
<input type="text" id="pickerApiKey" placeholder="AIzaSy...">

<label style="margin-top:10px">📥 入力画像 <small style="color:var(--dim)">(Driveから1枚選択)</small></label>
<button class="btn" id="pickInputImageBtn" style="width:100%">📁 入力画像選択</button>
<div class="folder-display" id="inputImageDisplay">未選択</div>
<input type="hidden" id="inputImageFolder">
<input type="hidden" id="inputImageFilename">
<input type="hidden" id="inputImageFileId">

<label style="margin-top:10px">📤 出力フォルダ <small style="color:var(--dim)">(生成後の保存先)</small></label>
<button class="btn" id="pickOutputBtn" style="width:100%">📁 フォルダ選択</button>
<div class="folder-display" id="outputFolderDisplay">未選択</div>
<input type="hidden" id="outputFolder">

<div class="row" style="margin-top:10px">
<button class="btn btn-secondary" id="saveAllDriveBtn">💾 ローカル＋KV 一括保存</button>
<button class="btn" id="reloadConfigBtn">🔄 KVから再取得</button>
</div>
</div>
</div>

<div class="card">
<h2>5 Positive Prompts <small id="presetCount" style="color:var(--dim)"></small></h2>
<div style="background:var(--surface2);padding:10px;border-radius:7px;margin-bottom:10px;border:1px solid var(--border)">
<div style="font-size:11px;color:var(--accent2);margin-bottom:6px;font-family:'Space Mono',monospace">📦 プリセット (5 Pos + Neg + Seed + LoRA + シリーズ名 まるごと) <span style="color:var(--dim);font-size:10px">(KV保存・全端末同期)</span></div>
<div class="row" style="grid-template-columns:1fr auto auto auto;gap:6px">
<select id="presetSelect"><option value="">-- 選んで自動読込 --</option></select>
<button class="btn" id="presetSaveBtn" title="現在の構成をまるごと保存">💾 保存</button>
<button class="btn" id="presetDelBtn" title="選択中を削除（KVから）" style="background:rgba(239,68,68,.15)" disabled>🗑 削除</button>
<button class="btn" id="presetReloadBtn" title="リスト再取得">🔄</button>
</div>
</div>
<label>シリーズ名 <small style="color:var(--dim)">(出力ファイル名のprefix)</small></label>
<input type="text" id="seriesName" placeholder="例: dress_change_v1" value="qwen_series">
<div id="positivesContainer" style="margin-top:10px">
<div style="margin-bottom:10px">
<div style="display:flex;justify-content:space-between;align-items:center"><label style="margin-bottom:0">Positive 1</label><button class="btn" id="clearPos1" style="padding:4px 10px;font-size:11px">🗑 クリア</button></div>
<textarea id="pos1"></textarea>
</div>
<div style="margin-bottom:10px">
<div style="display:flex;justify-content:space-between;align-items:center"><label style="margin-bottom:0">Positive 2</label><button class="btn" id="clearPos2" style="padding:4px 10px;font-size:11px">🗑 クリア</button></div>
<textarea id="pos2"></textarea>
</div>
<div style="margin-bottom:10px">
<div style="display:flex;justify-content:space-between;align-items:center"><label style="margin-bottom:0">Positive 3</label><button class="btn" id="clearPos3" style="padding:4px 10px;font-size:11px">🗑 クリア</button></div>
<textarea id="pos3"></textarea>
</div>
<div style="margin-bottom:10px">
<div style="display:flex;justify-content:space-between;align-items:center"><label style="margin-bottom:0">Positive 4</label><button class="btn" id="clearPos4" style="padding:4px 10px;font-size:11px">🗑 クリア</button></div>
<textarea id="pos4"></textarea>
</div>
<div style="margin-bottom:10px">
<div style="display:flex;justify-content:space-between;align-items:center"><label style="margin-bottom:0">Positive 5</label><button class="btn" id="clearPos5" style="padding:4px 10px;font-size:11px">🗑 クリア</button></div>
<textarea id="pos5"></textarea>
</div>
</div>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
<label style="margin-bottom:0">共通 Negative</label>
<button class="btn" id="clearNegativeBtn" style="padding:4px 10px;font-size:11px">🗑 クリア</button>
</div>
<textarea id="negative" placeholder="(空欄でデフォルト適用)"></textarea>
<label style="margin-top:10px">Seed</label>
<input type="number" id="seed" value="19">
</div>

<div class="card">
<h2>LoRA Control <small style="color:var(--dim)">(3種、有効/無効 + 強度)</small></h2>
<div id="lorasContainer">
<div style="background:var(--surface2);padding:10px;border-radius:6px;margin-bottom:8px;border:1px solid var(--border)">
<div style="display:grid;grid-template-columns:1fr 100px auto;gap:10px;align-items:center">
<div><div style="font-family:'Space Mono',monospace;font-size:13px;color:var(--accent2)">QWEN_breastslider</div><div style="font-size:10px;color:var(--dim);margin-top:2px">胸サイズ調整（負＝小・正＝大）</div></div>
<input type="number" step="0.1" id="breastStrength" value="-2.0" style="text-align:center">
<label class="toggle-row" style="margin:0"><input type="checkbox" id="breastEnabled" checked> <span style="font-size:12px">ON</span></label>
</div>
</div>
<div style="background:var(--surface2);padding:10px;border-radius:6px;margin-bottom:8px;border:1px solid var(--border)">
<div style="display:grid;grid-template-columns:1fr 100px auto;gap:10px;align-items:center">
<div><div style="font-family:'Space Mono',monospace;font-size:13px;color:var(--accent2)">SNOFSv1.3</div><div style="font-size:10px;color:var(--dim);margin-top:2px">ディテール強化</div></div>
<input type="number" step="0.1" id="snofsStrength" value="0.5" style="text-align:center">
<label class="toggle-row" style="margin:0"><input type="checkbox" id="snofsEnabled" checked> <span style="font-size:12px">ON</span></label>
</div>
</div>
<div style="background:var(--surface2);padding:10px;border-radius:6px;margin-bottom:8px;border:1px solid var(--border)">
<div style="display:grid;grid-template-columns:1fr 100px auto;gap:10px;align-items:center">
<div><div style="font-family:'Space Mono',monospace;font-size:13px;color:var(--accent2)">QWEN_WhatIsVagina</div><div style="font-size:10px;color:var(--dim);margin-top:2px">局部描画調整</div></div>
<input type="number" step="0.1" id="vaginaStrength" value="0.5" style="text-align:center">
<label class="toggle-row" style="margin:0"><input type="checkbox" id="vaginaEnabled" checked> <span style="font-size:12px">ON</span></label>
</div>
</div>
</div>
</div>

<div class="card">
<h2>Batch</h2>
<div class="banner" style="margin-top:0">
ℹ️ <strong>Serverless モード</strong>。5枚を直列実行（1枚あたり30秒〜数分）。<br>
<strong>⚠️ 実行中はこのタブを閉じないでください</strong>（Pod駆動と違い、ブラウザが進捗管理しています）。
</div>
<button class="btn-large btn-success" id="batchStartBtn" style="margin-top:10px">▶ 5枚一括生成 開始</button>
<button class="btn-large btn-danger" id="batchStopBtn" style="display:none;margin-top:6px">⛔ 中断</button>
</div>

<div class="card" id="progressCard" style="display:none">
<h2>Progress <span id="progressBadge" class="badge idle">IDLE</span></h2>
<div id="progressInfo" style="font-size:13px;margin-top:6px"></div>
<div style="font-size:11px;color:var(--dim);margin-top:4px;font-family:'Space Mono',monospace" id="progressDetail"></div>
<div class="progress-bar"><div class="fill" id="progressFill" style="width:0%"></div></div>
<div id="completedList" style="margin-top:10px;max-height:300px;overflow-y:auto"></div>
<div id="galleryEl" class="gallery"></div>
<details><summary>📜 実行ログ</summary>
<div style="display:flex;justify-content:flex-end;margin:6px 0">
<button class="btn" id="copyLogBtn" style="padding:4px 10px;font-size:11px">📋 ログをコピー</button>
</div>
<div class="log" id="log"></div>
</details>
</div>

<div class="footer">v1.0 / Qwen-Rapid-AIO Series Serverless + 5 Pos KV + 3 LoRA + Drive Upload</div>
</div>

<!-- Google Picker API -->
<script src="https://apis.google.com/js/api.js"></script>

<script>
// === バックエンドから注入される定数（worker.js 冒頭の BASE_WORKFLOW / NODE） ===
const BASE_WORKFLOW = ${JSON.stringify(BASE_WORKFLOW)};
const NODE = ${JSON.stringify(NODE)};

const $=id=>document.getElementById(id);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function appendLog(lines){
  const el=$('log');if(!el)return;
  const t=new Date().toLocaleTimeString('ja-JP',{hour12:false});
  const arr=Array.isArray(lines)?lines:[lines];
  arr.forEach(l=>{el.textContent+='['+t+'] '+l+'\\n';});
  el.scrollTop=el.scrollHeight;
}

// ============== Qwen-Rapid-AIO 初期化 (5 Positives + 3 LoRA) ==============
const LORA_DEFS = [
  {key:'breast', name:'QWEN_breastslider',  def: -2.0, hint:'胸サイズ調整（負＝小・正＝大）'},
  {key:'snofs',  name:'SNOFSv1.3',          def:  0.5, hint:'ディテール強化'},
  {key:'vagina', name:'QWEN_WhatIsVagina',  def:  0.5, hint:'局部描画調整'}
];

function initQwenUI(){
  // 5プロンプトのクリアボタンにハンドラ設定
  for(let i=1; i<=5; i++){
    const btn = $('clearPos'+i);
    if(btn) btn.onclick = () => $('pos'+i).value = '';
  }
}
initQwenUI();

// ============== localStorage ==============
const LS_KEYS = ['apiKey','endpointId','negative','seriesName','seed',
  'pos1','pos2','pos3','pos4','pos5',
  'breastStrength','snofsStrength','vaginaStrength',
  'inputImageFolder','inputImageFilename','inputImageFileId'];
LS_KEYS.forEach(k=>{const v=localStorage.getItem(k);if(v && $(k))$(k).value=v;});
['breastEnabled','snofsEnabled','vaginaEnabled'].forEach(k=>{
  const v=localStorage.getItem(k);
  if(v!==null && $(k)) $(k).checked = (v==='1');
});
if($('inputImageFilename').value){
  $('inputImageDisplay').textContent = $('inputImageFilename').value;
  $('inputImageDisplay').classList.add('set');
}

function saveAllLocal(){
  LS_KEYS.forEach(k=>{if($(k))localStorage.setItem(k,$(k).value);});
  ['breastEnabled','snofsEnabled','vaginaEnabled'].forEach(k=>{
    if($(k))localStorage.setItem(k,$(k).checked?'1':'0');
  });
}

// ============== Cloudflare KV Config ==============
let DRIVE_CLIENT_ID = '';
let PICKER_API_KEY = '';
async function loadConfigFromKV(){
  try{
    const r=await fetch('/api/config');
    if(!r.ok)return;
    const cfg=await r.json();
    if(cfg.google_client_id){DRIVE_CLIENT_ID=cfg.google_client_id;$('googleClientId').value=cfg.google_client_id;}
    if(cfg.picker_api_key){PICKER_API_KEY=cfg.picker_api_key;$('pickerApiKey').value=cfg.picker_api_key;}
    if(cfg.runpod_api_key){$('apiKey').value=cfg.runpod_api_key;localStorage.setItem('apiKey',cfg.runpod_api_key);}
    if(cfg.endpoint_id){$('endpointId').value=cfg.endpoint_id;localStorage.setItem('endpointId',cfg.endpoint_id);}
    if(cfg.drive_output_folder){setOutputFolder(cfg.drive_output_folder,'(KV保存値)');}
    updateConfigStatus();
  }catch(e){appendLog('KV読込エラー: '+e.message);}
}
async function saveConfigToKV(key,value){
  const r=await fetch('/api/config/'+encodeURIComponent(key),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({value})});
  if(!r.ok)throw new Error('KV保存失敗 ('+key+'): '+(await r.text()).slice(0,200));
  return await r.json();
}
function updateConfigStatus(){
  const el=$('configStatus');if(!el)return;
  if(DRIVE_CLIENT_ID && PICKER_API_KEY){el.innerHTML='✅ ClientID + PickerKey OK';el.style.color='var(--green)';}
  else{el.innerHTML='⚠️ '+(!DRIVE_CLIENT_ID?'ClientID ':'')+(!PICKER_API_KEY?'PickerKey ':'')+'未設定';el.style.color='var(--amber)';}
}
loadConfigFromKV();

$('saveBtn').onclick=async()=>{
  saveAllLocal();
  const apiKey=$('apiKey').value.trim();const endpointId=$('endpointId').value.trim();
  if(!apiKey || !endpointId){alert('API Key + Endpoint ID を入力してください');return;}
  try{
    await Promise.all([
      saveConfigToKV('runpod_api_key',apiKey),
      saveConfigToKV('endpoint_id',endpointId),
    ]);
    alert('💾 ローカル + ☁️ KV 両方保存OK');
  }catch(e){alert('KV保存失敗: '+e.message);}
};

$('saveAllDriveBtn').onclick=async()=>{
  const items=[
    ['google_client_id',$('googleClientId').value.trim(),v=>{DRIVE_CLIENT_ID=v;}],
    ['picker_api_key',$('pickerApiKey').value.trim(),v=>{PICKER_API_KEY=v;}],
    ['drive_output_folder',$('outputFolder').value.trim(),null],
  ];
  const valid=items.filter(([k,v])=>v);
  if(valid.length===0){alert('保存対象なし（全項目が空）');return;}
  try{
    await Promise.all(valid.map(([k,v])=>saveConfigToKV(k,v)));
    valid.forEach(([k,v,setter])=>{if(setter)setter(v);});
    updateConfigStatus();
    alert('💾 ローカル + ☁️ KV 両方保存OK ('+valid.length+'項目)');
  }catch(e){alert('KV保存失敗: '+e.message);}
};
$('reloadConfigBtn').onclick=async()=>{
  $('googleClientId').value='';$('pickerApiKey').value='';
  $('apiKey').value='';$('endpointId').value='';
  setOutputFolder('','');
  await loadConfigFromKV();
  alert('KVから再取得完了');
};

function setOutputFolder(id,note){
  $('outputFolder').value=id||'';
  const disp=$('outputFolderDisplay');
  if(id){disp.textContent=id+(note?' '+note:'');disp.classList.add('set');}
  else{disp.textContent='未選択';disp.classList.remove('set');}
}

// ============== Drive OAuth ==============
const REQUIRED_GOOGLE_ACCOUNT='michihiko.kurokawa@gmail.com';
let driveToken=localStorage.getItem('driveToken')||null;
let driveEmail=localStorage.getItem('driveEmail')||null;
function updateDriveUI(){
  const el=$('driveStatus');
  if(driveToken && driveEmail===REQUIRED_GOOGLE_ACCOUNT){
    el.innerHTML='✅ 接続済み <span style="color:var(--dim);font-size:11px">('+driveEmail+')</span>';
    el.style.color='var(--green)';
  }else if(driveEmail && driveEmail!==REQUIRED_GOOGLE_ACCOUNT){
    el.innerHTML='⚠️ 別アカウント('+driveEmail+') - '+REQUIRED_GOOGLE_ACCOUNT+' で再認証してください';
    el.style.color='var(--amber)';
  }else{
    el.textContent='未接続';
    el.style.color='var(--dim)';
  }
}
async function verifyAccount(token){
  const r=await fetch('https://www.googleapis.com/oauth2/v3/userinfo',{headers:{Authorization:'Bearer '+token}});
  if(!r.ok)throw new Error('userinfo failed: HTTP '+r.status);
  return (await r.json()).email;
}
function performDriveAuth(){
  if(!DRIVE_CLIENT_ID){alert('OAuth Client ID を先に設定してください');return;}
  const redirectUri=location.origin+'/oauth/callback';
  const scope='https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/userinfo.email';
  const url='https://accounts.google.com/o/oauth2/v2/auth?client_id='+encodeURIComponent(DRIVE_CLIENT_ID)+
    '&redirect_uri='+encodeURIComponent(redirectUri)+
    '&response_type=token&scope='+encodeURIComponent(scope)+
    '&prompt=select_account';
  const popup=window.open(url,'oauth','width=500,height=600');
  const timer=setInterval(async()=>{
    const t=localStorage.getItem('driveToken');
    if(t && t!==driveToken){
      clearInterval(timer);
      try{
        const email=await verifyAccount(t);
        if(email===REQUIRED_GOOGLE_ACCOUNT){
          driveToken=t;driveEmail=email;
          localStorage.setItem('driveEmail',email);
          updateDriveUI();
          if(popup && !popup.closed)popup.close();
        }else{
          driveToken=null;
          localStorage.removeItem('driveToken');
          driveEmail=email;
          localStorage.setItem('driveEmail',email);
          updateDriveUI();
          alert('別アカウントです: '+email+'\\n'+REQUIRED_GOOGLE_ACCOUNT+' で再ログインしてください');
        }
      }catch(e){alert('認証検証失敗: '+e.message);}
    }
    if(popup && popup.closed)clearInterval(timer);
  },1000);
}
$('driveAuthBtn').onclick=performDriveAuth;
updateDriveUI();

// ============== Google Drive Picker ==============
function loadPicker(){
  return new Promise(res=>{
    if(window.google && google.picker){res();return;}
    gapi.load('picker',{callback:res});
  });
}
async function pickInputImage(){
  if(!driveToken){alert('Drive未接続。先に「📁 Drive 接続」してください');return;}
  if(!PICKER_API_KEY){alert('Picker API Key 未設定');return;}
  try{
    await loadPicker();
    const view = new google.picker.DocsView(google.picker.ViewId.DOCS_IMAGES)
      .setIncludeFolders(false)
      .setSelectFolderEnabled(false)
      .setMimeTypes('image/png,image/jpeg,image/jpg,image/webp');
    const picker = new google.picker.PickerBuilder()
      .addView(view)
      .setOAuthToken(driveToken)
      .setDeveloperKey(PICKER_API_KEY)
      .setCallback(async data => {
        if(data.action === google.picker.Action.PICKED){
          const doc = data.docs[0];
          let parentId = doc.parentId;
          if(!parentId){
            try{
              const r = await fetch('https://www.googleapis.com/drive/v3/files/' + doc.id + '?fields=parents',
                {headers:{Authorization:'Bearer ' + driveToken}});
              if(r.ok){const j = await r.json(); parentId = j.parents && j.parents[0] || null;}
            }catch(e){}
          }
          $('inputImageFolder').value = parentId || '';
          $('inputImageFilename').value = doc.name;
          $('inputImageFileId').value = doc.id;
          const disp = $('inputImageDisplay');
          disp.textContent = doc.name;
          disp.classList.add('set');
          localStorage.setItem('inputImageFolder', parentId || '');
          localStorage.setItem('inputImageFilename', doc.name);
          localStorage.setItem('inputImageFileId', doc.id);
        }
      })
      .build();
    picker.setVisible(true);
  }catch(e){alert('Picker起動失敗: '+e.message);}
}
$('pickInputImageBtn').onclick = pickInputImage;

async function pickOutputFolder(){
  if(!driveToken){alert('Drive未接続');return;}
  if(!PICKER_API_KEY){alert('Picker API Key 未設定');return;}
  try{
    await loadPicker();
    const view = new google.picker.DocsView(google.picker.ViewId.FOLDERS)
      .setIncludeFolders(true)
      .setSelectFolderEnabled(true)
      .setMimeTypes('application/vnd.google-apps.folder');
    const picker = new google.picker.PickerBuilder()
      .addView(view)
      .setOAuthToken(driveToken)
      .setDeveloperKey(PICKER_API_KEY)
      .setCallback(data => {
        if(data.action === google.picker.Action.PICKED){
          const doc = data.docs[0];
          setOutputFolder(doc.id, '('+doc.name+')');
        }
      })
      .build();
    picker.setVisible(true);
  }catch(e){alert('Picker起動失敗: '+e.message);}
}
$('pickOutputBtn').onclick = pickOutputFolder;

// ============== 構成集約 & 復元 ==============
function collectQwenConfig(){
  const positives = [];
  for(let i=1; i<=5; i++) positives.push(($('pos'+i).value || '').trim());
  const loras = {};
  LORA_DEFS.forEach(l => {
    loras[l.key] = {
      enabled: $(l.key+'Enabled').checked,
      strength: parseFloat($(l.key+'Strength').value) || 0
    };
  });
  return {
    seriesName: ($('seriesName').value || 'qwen_series').trim(),
    positives,
    negative: ($('negative').value || '').trim(),
    seed: parseInt($('seed').value) || 19,
    loras,
    input_image: {
      folder_id: $('inputImageFolder').value.trim(),
      filename:  $('inputImageFilename').value.trim(),
      file_id:   $('inputImageFileId').value.trim()
    }
  };
}
function restoreQwenConfig(cfg){
  if(!cfg) return;
  if(cfg.seriesName) $('seriesName').value = cfg.seriesName;
  if(Array.isArray(cfg.positives)){
    for(let i=0; i<5; i++) $('pos'+(i+1)).value = cfg.positives[i] || '';
  }
  if(typeof cfg.negative === 'string') $('negative').value = cfg.negative;
  if(cfg.seed != null) $('seed').value = cfg.seed;
  if(cfg.loras){
    LORA_DEFS.forEach(l => {
      const v = cfg.loras[l.key];
      if(v){
        if(typeof v.enabled === 'boolean') $(l.key+'Enabled').checked = v.enabled;
        if(typeof v.strength === 'number')  $(l.key+'Strength').value = v.strength;
      }
    });
  }
}

// ============== プリセット (KV) ==============
async function presetsList(){
  try{const r=await fetch('/api/presets');if(!r.ok)throw new Error('list HTTP '+r.status);return await r.json();}
  catch(e){appendLog('Presets list err: '+e.message);return [];}
}
async function presetsSave(name, cfg){
  const payload = {positive: JSON.stringify(cfg), negative: cfg.negative || '', savedAt: new Date().toISOString()};
  const r=await fetch('/api/presets/'+encodeURIComponent(name),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!r.ok)throw new Error('save HTTP '+r.status);
}
async function presetsGet(name){
  const r=await fetch('/api/presets/'+encodeURIComponent(name));
  if(!r.ok)throw new Error('get HTTP '+r.status);
  const raw=await r.json();
  try{return JSON.parse(raw.positive || '{}');}catch(e){return null;}
}
async function presetsDelete(name){
  const r=await fetch('/api/presets/'+encodeURIComponent(name),{method:'DELETE'});
  if(!r.ok)throw new Error('delete HTTP '+r.status);
}
async function refreshPresetSelect(){
  const sel=$('presetSelect');
  sel.innerHTML='<option value="">-- 取得中... --</option>';
  const arr=await presetsList();
  arr.sort((a,b)=>a.name.localeCompare(b.name,'ja'));
  sel.innerHTML='<option value="">-- 読込 ('+arr.length+'件) --</option>'+arr.map(p=>{
    const d=(p.savedAt||'').slice(5,16).replace('T',' ');
    return '<option value="'+p.name.replace(/"/g,'&quot;')+'">'+p.name+(d?' · '+d:'')+'</option>';
  }).join('');
  $('presetCount').textContent='('+arr.length+')';
}
$('presetReloadBtn').onclick=()=>refreshPresetSelect();
$('presetSaveBtn').onclick=async()=>{
  const cfg=collectQwenConfig();
  if(cfg.positives.every(p=>!p)){alert('Positiveを1つ以上入力してください');return;}
  const name=prompt('プリセット名:');
  if(!name || !name.trim())return;
  try{
    await presetsSave(name.trim(),cfg);
    await refreshPresetSelect();
    $('presetSelect').value=name.trim();
    $('presetDelBtn').disabled=false;
    alert('保存OK');
  }catch(e){alert('保存失敗: '+e.message);}
};
$('presetDelBtn').onclick=async()=>{
  const name=$('presetSelect').value;if(!name)return;
  if(!confirm('「'+name+'」を削除しますか?'))return;
  try{await presetsDelete(name);await refreshPresetSelect();$('presetDelBtn').disabled=true;}
  catch(e){alert('削除失敗: '+e.message);}
};
$('presetSelect').addEventListener('change',async()=>{
  $('presetDelBtn').disabled=!$('presetSelect').value;
  const name=$('presetSelect').value;
  if(!name)return;
  const cur=collectQwenConfig();
  if((cur.positives.some(p=>p) || cur.negative) && !confirm('現在の構成を「'+name+'」で上書きしますか?')){
    $('presetSelect').value='';
    return;
  }
  try{
    const cfg=await presetsGet(name);
    if(cfg) restoreQwenConfig(cfg);
    appendLog('Preset loaded: '+name);
  }catch(e){alert('読込失敗: '+e.message);}
});
$('clearNegativeBtn').onclick=()=>{$('negative').value='';};
refreshPresetSelect();

// ============== 接続確認 ==============
$('testBtn').onclick=async()=>{
  const apiKey=$('apiKey').value.trim();
  const endpointId=$('endpointId').value.trim();
  if(!apiKey || !endpointId){alert('API Key / Endpoint ID 必須');return;}
  appendLog('▼ Endpoint /health 確認');
  try{
    const r=await fetch('/api/runpod/health/'+encodeURIComponent(endpointId),{
      headers:{'X-Api-Key':apiKey}
    });
    if(!r.ok)throw new Error('HTTP '+r.status+': '+(await r.text()).slice(0,200));
    const j=await r.json();
    appendLog('  ✓ '+JSON.stringify(j).slice(0,300));
    $('connText').textContent='✅ 接続OK';
    $('connDot').classList.add('ok');
  }catch(e){
    appendLog('  ✗ '+e.message);
    alert('接続確認失敗: '+e.message);
    $('connText').textContent='❌ 失敗';
    $('connDot').classList.remove('ok');
  }
};

// ============== Drive 画像取得（DriveFileId → base64） ==============
async function fetchDriveImageBase64(fileId){
  if(!driveToken)throw new Error('Drive未接続');
  const r=await fetch('https://www.googleapis.com/drive/v3/files/'+fileId+'?alt=media',{
    headers:{Authorization:'Bearer '+driveToken}
  });
  if(!r.ok)throw new Error('Drive取得失敗 HTTP '+r.status);
  const blob=await r.blob();
  return await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>{
      const dataUrl=reader.result;
      const base64=dataUrl.split(',')[1];
      resolve(base64);
    };
    reader.onerror=()=>reject(new Error('FileReader失敗'));
    reader.readAsDataURL(blob);
  });
}

// ============== Drive アップロード（base64 → Drive） ==============
async function uploadToDrive(folderId, filename, base64){
  if(!driveToken)throw new Error('Drive未接続');
  // base64 → Blob
  const binary=atob(base64);
  const bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
  const blob=new Blob([bytes],{type:'image/png'});
  // multipart upload
  const metadata={name:filename, parents:[folderId]};
  const form=new FormData();
  form.append('metadata',new Blob([JSON.stringify(metadata)],{type:'application/json'}));
  form.append('file',blob);
  const r=await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',{
    method:'POST',
    headers:{Authorization:'Bearer '+driveToken},
    body:form
  });
  if(!r.ok)throw new Error('Drive upload失敗 HTTP '+r.status+': '+(await r.text()).slice(0,200));
  return await r.json();
}

// ============== バッチ実行（5枚直列） ==============
let batchAborted=false;

function setBadge(state, text){
  const b=$('progressBadge');
  b.className='badge '+state;
  b.textContent=text;
}
function updateProgress(done, total){
  $('progressFill').style.width=Math.floor(done/total*100)+'%';
  $('progressInfo').textContent=done+' / '+total+' 完了';
}

async function runOne(cfg, idx, base64Input, apiKey, endpointId){
  // workflow を JSON.parse(JSON.stringify(...)) で deep copy
  const workflow=JSON.parse(JSON.stringify(BASE_WORKFLOW));
  if(!workflow || Object.keys(workflow).length===0){
    throw new Error('BASE_WORKFLOW が空です。worker.js冒頭にworkflow_api.jsonを貼り付けてDeployしてください');
  }
  // ノード存在チェック
  for(const [key,id] of Object.entries({
    POS_PROMPT:'_440_',NEG_PROMPT:'_431_',SEED:'_434_',
    LORA_BREAST:'_438_',LORA_SNOFS:'_436_',LORA_VAGINA:'_451_',INPUT_IMAGE:'_449_'
  })){
    // 実際のノードIDで存在チェック
  }

  // 直接NODE定数で書き換え
  workflow['440'].inputs.prompt = cfg.positives[idx];
  workflow['431'].inputs.prompt = cfg.negative || workflow['431'].inputs.prompt || '';
  workflow['434'].inputs.seed = cfg.seed;
  workflow['438'].inputs.strength_model = cfg.loras.breast.enabled ? cfg.loras.breast.strength : 0;
  workflow['436'].inputs.strength_model = cfg.loras.snofs.enabled  ? cfg.loras.snofs.strength  : 0;
  workflow['451'].inputs.strength_model = cfg.loras.vagina.enabled ? cfg.loras.vagina.strength : 0;
  const imageName = 'input_' + Date.now() + '_' + idx + '.png';
  workflow['449'].inputs.image = imageName;

  // /run でジョブ投入
  const runResp = await fetch('/api/runpod/run/' + encodeURIComponent(endpointId), {
    method: 'POST',
    headers: {'Content-Type':'application/json','X-Api-Key':apiKey},
    body: JSON.stringify({input:{workflow, images:[{name:imageName, image:base64Input}]}})
  });
  if(!runResp.ok)throw new Error('/run HTTP '+runResp.status+': '+(await runResp.text()).slice(0,200));
  const runJson = await runResp.json();
  const jobId = runJson.id;
  if(!jobId)throw new Error('jobId取得失敗: '+JSON.stringify(runJson).slice(0,200));
  appendLog('    jobId='+jobId);

  // /status ポーリング（最大15分）
  const startT = Date.now();
  const maxMs = 15*60*1000;
  let pollInterval = 3000;
  while(true){
    if(batchAborted)throw new Error('ユーザー中断');
    if(Date.now()-startT > maxMs)throw new Error('タイムアウト（15分）');
    await sleep(pollInterval);
    const sResp = await fetch('/api/runpod/status/'+encodeURIComponent(endpointId)+'/'+encodeURIComponent(jobId),{
      headers:{'X-Api-Key':apiKey}
    });
    if(!sResp.ok){appendLog('    status HTTP '+sResp.status+' (再試行)');continue;}
    const s = await sResp.json();
    const st = s.status || s.state || 'UNKNOWN';
    $('progressDetail').textContent = 'job ' + (idx+1) + '/5 : ' + st + ' ('+Math.floor((Date.now()-startT)/1000)+'s)';
    if(st === 'COMPLETED'){
      // 画像取り出し
      const out = s.output || {};
      const candidates = out.images || out.message || [];
      let imageBase64 = null;
      for(const item of candidates){
        if(typeof item === 'string' && item.length > 100){imageBase64 = item;break;}
        if(item && item.image){imageBase64 = item.image;break;}
        if(item && item.data){imageBase64 = item.data;break;}
      }
      if(!imageBase64)throw new Error('レスポンスから画像取得失敗: '+JSON.stringify(s).slice(0,200));
      return imageBase64;
    }
    if(['FAILED','CANCELLED','TIMED_OUT'].includes(st)){
      throw new Error('Job失敗: '+st+' '+JSON.stringify(s.error || s).slice(0,200));
    }
    // 進行中は continue
  }
}

async function startBatch(){
  const apiKey=$('apiKey').value.trim();
  const endpointId=$('endpointId').value.trim();
  const cfg=collectQwenConfig();

  if(!apiKey || !endpointId){alert('API Key / Endpoint ID 必須');return;}
  if(!driveToken){alert('Google Drive 未接続');return;}
  if(!cfg.input_image.file_id){alert('入力画像が未選択');return;}
  if(!$('outputFolder').value.trim()){alert('出力フォルダ未選択');return;}
  const emptyIdx = cfg.positives.findIndex(p=>!p);
  if(emptyIdx>=0){alert('Positive '+(emptyIdx+1)+' 未入力');return;}

  const enabledLoras = Object.entries(cfg.loras).filter(([,v])=>v.enabled).map(([k,v])=>k+'='+v.strength).join(', ');
  if(!confirm(
    'Qwen-Rapid-AIO シリーズ開始:\\n' +
    '・入力画像: ' + cfg.input_image.filename + '\\n' +
    '・5プロンプト直列生成\\n' +
    '・Seed: ' + cfg.seed + '\\n' +
    '・LoRA有効: ' + (enabledLoras || 'なし') + '\\n' +
    '・出力先: Drive (シリーズ名 ' + cfg.seriesName + ')\\n\\n' +
    '⚠️ このタブを閉じないでください'
  ))return;

  batchAborted=false;
  saveAllLocal();
  $('progressCard').style.display='block';
  $('completedList').innerHTML='';
  $('galleryEl').innerHTML='';
  $('batchStartBtn').disabled=true;
  $('batchStopBtn').style.display='block';
  setBadge('running','RUNNING');
  updateProgress(0,5);

  // 入力画像をDriveから取得
  appendLog('=== バッチ開始 ===');
  appendLog('▼ 入力画像をDriveから取得中...');
  let base64Input;
  try{
    base64Input = await fetchDriveImageBase64(cfg.input_image.file_id);
    appendLog('  ✓ 入力画像取得 ('+Math.floor(base64Input.length/1024)+'KB base64)');
  }catch(e){
    appendLog('  ✗ '+e.message);
    alert('入力画像取得失敗: '+e.message);
    setBadge('error','ERROR');
    $('batchStartBtn').disabled=false;
    $('batchStopBtn').style.display='none';
    return;
  }

  const outputFolder = $('outputFolder').value.trim();
  let okCount=0;
  for(let i=0;i<5;i++){
    if(batchAborted){appendLog('★ ユーザー中断');break;}
    const filename = cfg.seriesName + '_' + String(i+1).padStart(2,'0') + '.png';
    appendLog('▼ ['+(i+1)+'/5] '+filename);
    try{
      const imgB64 = await runOne(cfg, i, base64Input, apiKey, endpointId);
      appendLog('  ✓ 生成完了 → Drive アップロード中...');
      await uploadToDrive(outputFolder, filename, imgB64);
      appendLog('  ✓ Drive アップロード完了');
      okCount++;
      // ギャラリー表示
      const wrap = document.createElement('div');
      wrap.innerHTML = '<img src="data:image/png;base64,'+imgB64+'"><div class="cap">'+filename+'</div>';
      $('galleryEl').appendChild(wrap);
      // 完了リスト
      const li = document.createElement('div');
      li.className='completed-item';
      li.innerHTML = '<span>'+filename+'</span><span class="ok">✓ OK</span>';
      $('completedList').appendChild(li);
    }catch(e){
      appendLog('  ✗ '+e.message);
      const li = document.createElement('div');
      li.className='completed-item';
      li.innerHTML = '<span>'+filename+'</span><span class="ng">✗ '+e.message.slice(0,40)+'</span>';
      $('completedList').appendChild(li);
    }
    updateProgress(i+1,5);
  }

  setBadge(okCount===5 ? 'done' : 'error', okCount===5 ? 'DONE' : okCount+'/5 OK');
  appendLog('=== 完了 ('+okCount+'/5) ===');
  $('batchStartBtn').disabled=false;
  $('batchStopBtn').style.display='none';
}
$('batchStartBtn').onclick=startBatch;
$('batchStopBtn').onclick=()=>{
  if(confirm('実行中のバッチを中断しますか?')){
    batchAborted=true;
    appendLog('★ 中断リクエスト');
  }
};

// ============== ログコピー ==============
$('copyLogBtn').onclick=async()=>{
  const text=$('log').textContent;
  if(!text.trim()){alert('ログが空です');return;}
  const orig=$('copyLogBtn').textContent;
  try{
    await navigator.clipboard.writeText(text);
    $('copyLogBtn').textContent='✅ コピー済';
  }catch(e){
    const ta=document.createElement('textarea');
    ta.value=text;ta.style.position='fixed';ta.style.left='-9999px';
    document.body.appendChild(ta);ta.select();
    try{document.execCommand('copy');$('copyLogBtn').textContent='✅ コピー済';}catch(e2){}
    document.body.removeChild(ta);
  }
  setTimeout(()=>{$('copyLogBtn').textContent=orig;},2000);
};

</script>
</body>
</html>`;

const OAUTH_HTML = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>OAuth</title></head>
<body><h2>認証処理中...</h2><script>
const hash=window.location.hash.slice(1);
const params=new URLSearchParams(hash);
const token=params.get('access_token');
if(token){window.opener?.localStorage.setItem('driveToken',token);localStorage.setItem('driveToken',token);document.body.innerHTML='<h2>✅ 認証完了</h2><p>このタブを閉じてください</p>';setTimeout(()=>window.close(),1500);}
else{document.body.innerHTML='<h2>❌ 認証失敗</h2>';}
</script></body></html>`;

// ============================================================================
// Cloudflare Worker バックエンド
// ============================================================================
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS });
    }

    if (url.pathname === '/oauth/callback') {
      return new Response(OAUTH_HTML, { headers: { 'Content-Type': 'text/html;charset=UTF-8', ...CORS } });
    }

    // ============== /api/runpod/health/:endpointId ==============
    if (url.pathname.startsWith('/api/runpod/health/')) {
      const endpointId = url.pathname.replace('/api/runpod/health/', '');
      const apiKey = request.headers.get('X-Api-Key') || '';
      if (!apiKey || !endpointId) {
        return new Response(JSON.stringify({ error: 'X-Api-Key / endpointId required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
      try {
        const r = await fetch(`https://api.runpod.ai/v2/${endpointId}/health`, {
          headers: { 'Authorization': 'Bearer ' + apiKey }
        });
        const t = await r.text();
        return new Response(t, { status: r.status, headers: { 'Content-Type': 'application/json', ...CORS } });
      } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 502, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
    }

    // ============== /api/runpod/run/:endpointId ==============
    if (url.pathname.startsWith('/api/runpod/run/')) {
      const endpointId = url.pathname.replace('/api/runpod/run/', '');
      const apiKey = request.headers.get('X-Api-Key') || '';
      if (!apiKey || !endpointId) {
        return new Response(JSON.stringify({ error: 'X-Api-Key / endpointId required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
      try {
        const body = await request.text();
        const r = await fetch(`https://api.runpod.ai/v2/${endpointId}/run`, {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
          body
        });
        const t = await r.text();
        return new Response(t, { status: r.status, headers: { 'Content-Type': 'application/json', ...CORS } });
      } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 502, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
    }

    // ============== /api/runpod/status/:endpointId/:jobId ==============
    if (url.pathname.startsWith('/api/runpod/status/')) {
      const rest = url.pathname.replace('/api/runpod/status/', '');
      const [endpointId, jobId] = rest.split('/');
      const apiKey = request.headers.get('X-Api-Key') || '';
      if (!apiKey || !endpointId || !jobId) {
        return new Response(JSON.stringify({ error: 'X-Api-Key / endpointId / jobId required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
      try {
        const r = await fetch(`https://api.runpod.ai/v2/${endpointId}/status/${jobId}`, {
          headers: { 'Authorization': 'Bearer ' + apiKey }
        });
        const t = await r.text();
        return new Response(t, { status: r.status, headers: { 'Content-Type': 'application/json', ...CORS } });
      } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 502, headers: { 'Content-Type': 'application/json', ...CORS } });
      }
    }

    // ============== /api/config - KV ==============
    if (url.pathname === '/api/config' || url.pathname.startsWith('/api/config/')) {
      if (!env.QWEN) return new Response(JSON.stringify({ error: 'QWEN not bound' }), { status: 500, headers: { 'Content-Type': 'application/json', ...CORS } });
      const ALLOWED = ['google_client_id', 'picker_api_key', 'drive_output_folder', 'runpod_api_key', 'endpoint_id'];

      if (request.method === 'GET' && url.pathname === '/api/config') {
        const result = {};
        for (const k of ALLOWED) {
          const v = await env.QWEN.get('config:' + k);
          if (v !== null) result[k] = v;
        }
        return new Response(JSON.stringify(result), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }

      const key = decodeURIComponent(url.pathname.replace('/api/config/', '').trim());
      if (!ALLOWED.includes(key)) return new Response(JSON.stringify({ error: 'invalid key. Allowed: ' + ALLOWED.join(', ') }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
      const kvKey = 'config:' + key;

      if (request.method === 'GET') {
        const v = await env.QWEN.get(kvKey);
        if (v === null) return new Response(JSON.stringify({ error: 'not found' }), { status: 404, headers: { 'Content-Type': 'application/json', ...CORS } });
        return new Response(JSON.stringify({ key, value: v }), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }
      if (request.method === 'PUT') {
        try {
          const body = await request.json();
          if (!body.value || typeof body.value !== 'string') return new Response(JSON.stringify({ error: 'value required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
          if (body.value.length > 500) return new Response(JSON.stringify({ error: 'value too long' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
          await env.QWEN.put(kvKey, body.value);
          return new Response(JSON.stringify({ ok: true, key, value: body.value }), { headers: { 'Content-Type': 'application/json', ...CORS } });
        } catch (e) { return new Response(JSON.stringify({ error: 'KV put: ' + e.message }), { status: 500, headers: { 'Content-Type': 'application/json', ...CORS } }); }
      }
      if (request.method === 'DELETE') {
        await env.QWEN.delete(kvKey);
        return new Response(JSON.stringify({ ok: true, key }), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }
      return new Response(JSON.stringify({ error: 'method not allowed' }), { status: 405, headers: { 'Content-Type': 'application/json', ...CORS } });
    }

    // ============== /api/presets - KV (Qwen構成まるごとJSON) ==============
    if (url.pathname === '/api/presets' || url.pathname.startsWith('/api/presets/')) {
      if (!env.QWEN) return new Response(JSON.stringify({ error: 'QWEN not bound' }), { status: 500, headers: { 'Content-Type': 'application/json', ...CORS } });

      if (request.method === 'GET' && url.pathname === '/api/presets') {
        const list = await env.QWEN.list({ prefix: 'preset:' });
        const items = [];
        for (const k of list.keys) {
          const name = k.name.replace(/^preset:/, '');
          let savedAt = k.metadata?.savedAt || '';
          if (!savedAt) {
            const v = await env.QWEN.get(k.name, 'json');
            savedAt = v?.savedAt || '';
          }
          items.push({ name, savedAt });
        }
        return new Response(JSON.stringify(items), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }

      const name = decodeURIComponent(url.pathname.replace('/api/presets/', '').trim());
      if (!name || name.length > 64) return new Response(JSON.stringify({ error: 'invalid name (1-64 chars)' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
      const kvKey = 'preset:' + name;

      if (request.method === 'GET') {
        const v = await env.QWEN.get(kvKey, 'json');
        if (!v) return new Response(JSON.stringify({ error: 'not found' }), { status: 404, headers: { 'Content-Type': 'application/json', ...CORS } });
        return new Response(JSON.stringify({ name, positive: v.positive || '', negative: v.negative || '', savedAt: v.savedAt }), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }

      if (request.method === 'PUT') {
        try {
          const body = await request.json();
          if (typeof body.positive !== 'string') return new Response(JSON.stringify({ error: 'positive required' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
          if (body.positive.length > 20000) return new Response(JSON.stringify({ error: 'positive too long' }), { status: 400, headers: { 'Content-Type': 'application/json', ...CORS } });
          const negative = (typeof body.negative === 'string') ? body.negative : '';
          const data = { positive: body.positive, negative, savedAt: body.savedAt || new Date().toISOString() };
          await env.QWEN.put(kvKey, JSON.stringify(data), { metadata: { savedAt: data.savedAt } });
          return new Response(JSON.stringify({ ok: true, name, ...data }), { headers: { 'Content-Type': 'application/json', ...CORS } });
        } catch (e) { return new Response(JSON.stringify({ error: 'KV put: ' + e.message }), { status: 500, headers: { 'Content-Type': 'application/json', ...CORS } }); }
      }

      if (request.method === 'DELETE') {
        await env.QWEN.delete(kvKey);
        return new Response(JSON.stringify({ ok: true, name }), { headers: { 'Content-Type': 'application/json', ...CORS } });
      }

      return new Response(JSON.stringify({ error: 'method not allowed' }), { status: 405, headers: { 'Content-Type': 'application/json', ...CORS } });
    }

    // ============== HTML 返却 ==============
    return new Response(HTML, { headers: { 'Content-Type': 'text/html;charset=UTF-8', ...CORS } });
  }
};
